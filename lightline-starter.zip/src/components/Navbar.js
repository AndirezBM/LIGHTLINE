import React from 'react';

function Navbar() {
  return (
    <nav style={{ padding: '1rem', background: '#f0f0f0' }}>
      <span>LIGHTLINE</span>
    </nav>
  );
}

export default Navbar;